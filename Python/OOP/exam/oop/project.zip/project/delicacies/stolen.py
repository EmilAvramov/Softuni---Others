from project.delicacies.delicacy import Delicacy


class Stolen(Delicacy):
    def __init__(self, name: str, price: float) -> None:
        super().__init__(name, 250, price)

    def details(self):
        return f"Stolen {self.__name}: 250g - {self.__price:.2f}lv."
