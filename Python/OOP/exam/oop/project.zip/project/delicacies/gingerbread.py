from project.delicacies.delicacy import Delicacy


class Gingerbread(Delicacy):
    def __init__(self, name: str, price: float) -> None:
        super().__init__(name, 200, price)

    def details(self):
        return f"Gingerbread {self.__name}: 200g - {self.__price:.2f}lv."
