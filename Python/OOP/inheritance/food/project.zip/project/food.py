class Food:
    def __init__(self, _expiration: str) -> None:
        self.expiration_date = _expiration
