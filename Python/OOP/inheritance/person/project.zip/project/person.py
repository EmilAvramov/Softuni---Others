class Person:
    def __init__(self, _name: str, _age: int) -> None:
        self.name = _name
        self.age = _age