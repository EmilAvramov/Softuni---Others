from project.player import Player
from project.supply.supply import Supply


class Controller:
    def __init__(self) -> None:
        self.players: list = []
        self.supplies: list = []

    def find_player(self, name: str):
        for player in self.players:
            if player.name == name:
                return True
        return False

    def add_player(self, *players: Player):
        names: list = []
        for player in players:
            if self.find_player(player.name) is False:
                self.players.append(player)
                names.append(player.name)
        return f"Successfully added: {', '.join(names)}"

    def add_supply(self, *supplies: Supply):
        for supply in supplies:
            self.supplies.append(supply)

    def sustain(self, player_name: str, sustenance_type: str):
        pass

    def duel(self, first_player_name: str, second_player_name: str):
        pass

    def next_day(self):
        pass

    def __str__(self) -> str:
        pass
