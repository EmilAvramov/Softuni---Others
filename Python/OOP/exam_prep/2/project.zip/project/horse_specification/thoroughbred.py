from project.horse_specification.horse import Horse


class Thoroughbred(Horse):
    MAX_HORSE_SPEED = 140

    def __init__(self, name: str, speed: int) -> None:
        super().__init__(name, speed)

    def train(self):
        if self.speed <= 137:
            self.speed += 3
        else:
            self.speed = self.MAX_HORSE_SPEED
